# Run on your phone — GitHub Actions setup

The `.github/workflows/build.yml` file automatically builds the APK when you push to GitHub. You don't need a laptop.

## Steps (all from your phone)

### 1. Create a GitHub account (if you don't have one)
- Visit github.com on your phone
- Sign up for free

### 2. Create a new repository
- Go to github.com on your phone
- Tap the **+** icon (top right) → **New repository**
- Name it `doomscroll-brake-android`
- Make it **Public** (so GitHub Actions can run for free)
- Tap **Create repository**

### 3. Upload the files
- Go into your new repo
- Tap **Add file** → **Upload files**
- Select all the files from the zip (or copy-paste the code):
  - `settings.gradle.kts`
  - `build.gradle.kts`
  - `gradle.properties`
  - `app/build.gradle.kts`
  - `app/src/main/AndroidManifest.xml`
  - `app/src/main/java/app/doomscrollbrake/*.kt` (all 6 files)
  - `app/src/main/res/xml/accessibility_service_config.xml`
  - `app/src/main/res/values/strings.xml`
  - `app/src/main/res/drawable/ic_launcher.xml`
  - `.github/workflows/build.yml` (the workflow file)
  - `README.md`
- Tap **Commit changes**

### 4. Wait for the build
- Go to the **Actions** tab in your repo
- You'll see the build running (it takes 2–3 minutes)
- When it's done, tap the job name
- Scroll down to **Artifacts**
- Download `doomscroll-brake-debug` (contains the APK)

### 5. Install on your phone
- Download the zip from step 4
- Unzip it to get `app-debug.apk`
- Open the APK file on your phone (it will ask to install)
- Tap **Install**
- Then go to **Settings → Accessibility** and enable "Doomscroll Brake"

## Troubleshooting

**Build failed?**
- Check the **Actions** tab for error messages
- Most likely: Instagram's view IDs have changed (see the main README for how to fix)

**APK won't install?**
- Make sure you have "Unknown sources" enabled in Settings (varies by Android version)
- Try using Ax Installer app (from Play Store) to install it

**Already have the app installed?**
- Go to Settings → Apps → Doomscroll Brake → Uninstall first
- Then install the new version

## Updating later

When you update the code in GitHub, the APK rebuilds automatically. Just go to **Actions** and download the new artifact.
