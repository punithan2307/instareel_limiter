# Doomscroll Brake for Instagram — Android

An accessibility service for Android that watches the Instagram app while it's on screen and:

| Feature | What it does |
|---|---|
| **Finite feed** | After scrolling ~N screens on Home or Explore, a full-screen blocker appears. Tapping "Leave" goes Home; "Messages" opens the inbox. |
| **Scroll friction** | After ~N screens, a banner shows "you've scrolled this far". After M screens, a countdown pause (15 s, then 30 s, 45 s, 60 s) blocks the screen. You must click "Keep scrolling" when the countdown hits zero. |
| **One Reel at a time** | The Reels viewer is locked: a swipe toward the next Reel shows a block screen. Once your daily allowance (default 1) is used, further Reels are blocked. Re-opening a Reel you already saw is fine. |

The app runs in the background and only watches Instagram (package `com.instagram.android`). Nothing is stored or sent anywhere except to your own Android log.

## Install

**Prerequisites**
- Android 9 (API 28) or later
- Gradle 8+ (comes with Android Studio)
- Java 17+

**Build**
```bash
cd doomscroll-brake-android
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

**Install on device**
```bash
./gradlew installDebug
# or manually:
adb install app/build/outputs/apk/debug/app-debug.apk
```

Then:
1. Open the app
2. Tap **Open Android Accessibility Settings**
3. Find "Doomscroll Brake" and toggle it **on**
4. Grant the permission (the system will warn you what it can see; it's normal)
5. Go back to the app and adjust your limits

## Architecture

**Files**
```
manifest.xml         Declares the accessibility service and main activity
BrakeService.kt      The accessibility service (main logic)
  ├─ onAccessibilityEvent()   Watches scroll, click, screen-change events
  ├─ applyScreenRules()       Applies the right rule for Home/Explore/Reels/Messages
  ├─ addScroll(), startPause(), showPause()  Finite feed + friction
  └─ onReelsEntered(), onReelsScroll(), blockReels()  One-Reel lock

OverlayHost.kt       Creates and destroys overlays (full-screen covers and banner)
InstagramScreens.kt  Everything that depends on Instagram's view ids
Prefs.kt             Preferences and daily state (stored in SharedPreferences)
Ui.kt                Tiny helpers for building views (no layout XMLs)
MainActivity.kt      Settings screen
```

## Important notes

### Instagram's view ids change often
The app detects which screen you're on and intercepts swipes by looking at view ids in the accessibility tree. Instagram changes these between major versions. If a feature stops working:

1. Enable debug logging in the settings (checkbox at the bottom)
2. Open Instagram and do the action that fails (scroll, swipe to next Reel, etc.)
3. Run `adb logcat | grep "DSB"`
4. Look for lines like `screen -> FEED` and `ids: id1, id2, ...`
5. Update the constants in `InstagramScreens.kt` (the `const val` lines at the top)

You can also pull the XML hierarchy with:
```bash
adb shell uiautomator dump /tmp/dump.xml && adb pull /tmp/dump.xml
```
and search for Instagram's view ids by hand.

### Android 14+ may need extra setup
On Android 14+, the overlay (cover screens) may not appear if your device enforces restrictive overlay policies. This is an Android limitation, not a bug. The service still counts scrolls and blocks Reels; the visual feedback just won't show.

### What Android can and cannot slow
- ✅ Can block touches and keys after detection (that's what the pause does)
- ✅ Can watch and count scroll events
- ✅ Can draw overlays on top of any app
- ❌ Cannot slow down a touch scroll in progress (it's too low-level)
- ❌ Cannot intercept swipes on a per-pixel basis

So "friction" on Android is a nudge banner + a hard pause, not a gradual slow-down like on the web.

### Network and privacy
Nothing is sent anywhere. No analytics, no crash reporting, no ads. The service only reads accessibility events and logs to your local Android log. Counts are stored in your device's `SharedPreferences`.

### Permissions
The app asks for:
- `android:accessibilityservice.AccessibilityService` binding (required for accessibility service)
- No runtime permissions

That's it. Android will warn you in its accessibility settings that the service can see the content of all apps (that's how accessibility services work). This one only watches Instagram.

## Testing

If you want to test the pause and overlay logic without real Instagram, you could mock the accessibility events:
```kotlin
val event = AccessibilityEvent()
event.packageName = "com.instagram.android"
event.eventType = AccessibilityEvent.TYPE_VIEW_SCROLLED
event.scrollDeltaY = 2000
service.onAccessibilityEvent(event)
```

For real testing, install and enable the service, then scroll on the real Instagram app.

## Important: this project has not been compiled or tested yet

**This code was written but not compiled or run on a real device.** The syntax is valid Kotlin, but you should expect:

- Instagram's view IDs to have changed since the constants in `InstagramScreens.kt` were written
- Possible runtime crashes if the accessibility tree doesn't match expectations
- The overlay system to behave differently on different Android versions
- View IDs in `InstagramScreens.kt` to be **completely wrong** for your Instagram version

**Before deploying to a device:**
1. Build and install as described
2. Enable debug logging in settings
3. Open Instagram and interact with it (scroll, open Reels, etc.)
4. Run `adb logcat | grep DSB` to see what view IDs the service actually sees
5. Compare those IDs to what's in `InstagramScreens.kt` and update accordingly

This is a normal part of building accessibility services—Instagram's structure changes every few months, and finding the right IDs for your version is a one-time setup step.

## Known issues

- Reels counter may occasionally lag if Instagram loads a new Reel from cache without a scroll event
- The "opened a Reel you already watched is fine" rule depends on durable state; if you force-stop the app, the state resets
- Pause countdown may show 0 for a frame or two if the timer fires at exactly the same ms as the countdown check
- On Android 12–13, some OEM skins may block accessibility overlays; use a different launcher or ROM if overlays don't appear

## Building from source

**Requirements**
- Android Studio 2024.2+ or a text editor + Gradle 8.14+
- JDK 17+ (Android Studio includes one)
- Android SDK API 34 installed

**Steps**
```bash
git clone <this-repo>
cd doomscroll-brake-android
./gradlew build              # Compile
./gradlew assembleDebug      # Build APK
./gradlew installDebug       # Install to device
```

No third-party dependencies by design—everything uses only Android framework APIs.
