package app.doomscrollbrake

import android.view.accessibility.AccessibilityNodeInfo

enum class Screen { FEED, EXPLORE, REELS, MESSAGES, OTHER }

/**
 * Everything that depends on how the Instagram app labels its views lives in this file.
 *
 * Instagram does not publish these and changes them between versions, so the ids below are best guesses
 * and MUST be checked against your installed version (see README, "Finding Instagram's view ids").
 * If a feature stops working after an Instagram update, this is the file to adjust.
 */
object InstagramScreens {
    const val PACKAGE = "com.instagram.android"
    private const val P = "$PACKAGE:id/"

    // Bottom navigation tabs. The selected one tells us which screen is showing.
    const val TAB_FEED = P + "feed_tab"
    const val TAB_EXPLORE = P + "search_tab"
    const val TAB_REELS = P + "clips_tab"

    // Any view whose id contains this means the full-screen Reels viewer is showing
    // (it is also what a swipe to the next Reel scrolls).
    const val REELS_VIEWER_ID_PART = "clips_viewer"

    // Any view whose id contains one of these means a direct-message screen is showing.
    val MESSAGES_ID_PARTS = listOf("direct_thread", "thread_composer", "direct_inbox")

    // The paper-plane / inbox button in the Home header, used by "Open messages".
    val INBOX_BUTTON_IDS = listOf(P + "action_bar_inbox_button", P + "direct_tab")
    val INBOX_DESCRIPTIONS = listOf("messenger", "messages", "direct")

    // Tapping a button whose description starts with one of these counts as engaging with a post.
    val ENGAGEMENT_DESCRIPTION = Regex("^(like|unlike|comment|share|save|remove)", RegexOption.IGNORE_CASE)

    private const val MAX_NODES = 900

    /** Works out which Instagram screen is on display by walking the accessibility tree (bounded). */
    fun detect(root: AccessibilityNodeInfo): Screen {
        var reelsViewer = false
        var messages = false
        var selected: Screen? = null

        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeAt(stack.size - 1)
            visited++

            val id = node.viewIdResourceName
            if (id != null) {
                if (id.contains(REELS_VIEWER_ID_PART)) reelsViewer = true
                if (MESSAGES_ID_PARTS.any { id.contains(it) }) messages = true
                if (node.isSelected) {
                    when (id) {
                        TAB_FEED -> selected = Screen.FEED
                        TAB_EXPLORE -> selected = Screen.EXPLORE
                        TAB_REELS -> selected = Screen.REELS
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) stack.add(child)
            }
            if (node !== root) recycleCompat(node)
        }
        // Anything left over in the stack was fetched but never visited.
        for (n in stack) if (n !== root) recycleCompat(n)

        return when {
            messages -> Screen.MESSAGES
            reelsViewer -> Screen.REELS
            selected != null -> selected
            else -> Screen.OTHER
        }
    }

    // Source views whose scrolls must NOT count as "swiped to the next Reel" (comments sheet, etc.).
    val REELS_SCROLL_IGNORE_ID_PARTS = listOf("comment", "bottom_sheet", "sheet", "caption", "audio")

    /** Taps the Home tab in the bottom bar. Returns false if the bar is not on screen (full-screen viewer). */
    fun clickHomeTab(root: AccessibilityNodeInfo): Boolean {
        for (m in root.findAccessibilityNodeInfosByViewId(TAB_FEED)) {
            if (clickSelfOrParent(m)) return true
        }
        return false
    }

    /** Distinct view ids currently on screen, for the debug log. Bounded. */
    fun dumpIds(root: AccessibilityNodeInfo): List<String> {
        val out = LinkedHashSet<String>()
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeAt(stack.size - 1)
            visited++
            node.viewIdResourceName?.let { out.add(it.removePrefix(P) + if (node.isSelected) " [selected]" else "") }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) stack.add(child)
            }
        }
        return out.toList()
    }

    /** Clicks the Home header's messages button. Best effort; returns true if a click was sent. */
    fun clickInbox(root: AccessibilityNodeInfo): Boolean {
        for (id in INBOX_BUTTON_IDS) {
            val matches = root.findAccessibilityNodeInfosByViewId(id)
            for (m in matches) {
                if (clickSelfOrParent(m)) return true
            }
        }
        // Fallback: any node whose description mentions messages.
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeAt(stack.size - 1)
            visited++
            val desc = node.contentDescription?.toString()?.lowercase()
            if (desc != null && INBOX_DESCRIPTIONS.any { desc.contains(it) } && clickSelfOrParent(node)) return true
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) stack.add(child)
            }
        }
        return false
    }

    private fun clickSelfOrParent(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        var hops = 0
        while (n != null && hops < 5) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            hops++
        }
        return false
    }

    @Suppress("DEPRECATION")
    fun recycleCompat(node: AccessibilityNodeInfo?) {
        try {
            node?.recycle()
        } catch (_: Exception) {
            // Recycling is a no-op on newer Android versions and may throw if already recycled.
        }
    }
}
