package app.doomscrollbrake

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

/** Tiny view helpers so the overlays and settings screen do not need XML layouts or a theme. */
object Ui {
    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(context: Context, fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.setColor(fill)
        d.cornerRadius = dp(context, radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(context, strokeDp), strokeColor)
        return d
    }

    /** A full-width pill button built from a TextView. */
    fun button(context: Context, label: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(context)
        t.text = label
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(context, 16), dp(context, 14), dp(context, 16), dp(context, 14))
        if (primary) {
            t.setTextColor(0xFF111111.toInt())
            t.background = rounded(context, 0xFFFFFFFF.toInt(), 12)
        } else {
            t.setTextColor(0xFFFFFFFF.toInt())
            t.background = rounded(context, 0x00000000, 12, 0x38FFFFFF, 1)
        }
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }
}
