package app.doomscrollbrake

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The brain. Runs while Instagram is in front and:
 *
 *  1. Finite feed     counts how far you scroll on Home/Explore; past the daily budget it covers the screen.
 *  2. Scroll friction after N screens a banner shows; after M screens a countdown pause covers the screen.
 *  3. One Reel        entering the Reels viewer uses up one daily Reel. A swipe toward the next Reel is
 *                     answered with a cover screen and a step back out.
 *
 * Android cannot slow down a touch scroll, so "friction" here is a banner followed by a hard pause.
 */
class BrakeService : AccessibilityService() {

    private lateinit var prefs: Prefs
    private lateinit var state: DayState
    private lateinit var overlay: OverlayHost

    private var screenH = 2000
    private var cachedScreen = Screen.OTHER
    private var cachedAt = 0L

    private var reelsSession = false
    private var reelsEnteredAt = 0L
    private var reelsSwipePx = 0L
    private var reelsLastScrollAt = 0L
    private var lastReelBlockAt = 0L

    private var suppressCapUntil = 0L
    private var lastSaveAt = 0L
    private var lastLoggedScreen: Screen? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        state = DayState.get(this)
        overlay = OverlayHost(this)
        screenH = max(800, resources.displayMetrics.heightPixels)
    }

    override fun onInterrupt() {
        if (::overlay.isInitialized) overlay.hideAll()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (::overlay.isInitialized) overlay.hideAll()
        return super.onUnbind(intent)
    }

    /* ---------------------------------- events ---------------------------------- */

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::prefs.isInitialized) return

        val pkg = event.packageName?.toString()
        if (pkg != InstagramScreens.PACKAGE) {
            // Our own overlays and the system UI come through here; only a real app switch matters.
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                pkg != null && pkg != packageName && pkg != "com.android.systemui"
            ) {
                checkLeftInstagram()
            }
            return
        }

        if (!prefs.enabled) {
            leaveInstagram()
            return
        }
        if (state.rolloverIfNeeded()) {
            overlay.hideAll()
            reelsSession = false
        }

        val now = SystemClock.elapsedRealtime()
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> onScrolled(event, now)
            AccessibilityEvent.TYPE_VIEW_CLICKED -> onClicked(event)
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                refreshScreen(now, force = true)
                if (prefs.debugLog) dumpIdsToLog()
            }
            else -> refreshScreen(now, force = false)
        }
        applyScreenRules(now)
    }

    private fun onScrolled(event: AccessibilityEvent, now: Long) {
        val dy = abs(event.scrollDeltaY)
        val screen = refreshScreen(now, force = false)
        if (prefs.debugLog && dy > 0) {
            val id = event.source?.viewIdResourceName
            Log.d(TAG, "scroll dy=$dy screen=$screen src=${id ?: "null"} class=${event.className}")
        }
        if (dy <= 0) return
        when (screen) {
            Screen.FEED, Screen.EXPLORE -> if (overlay.kind == null) addScroll(dy, now)
            Screen.REELS -> onReelsScroll(event, dy, now)
            else -> {}
        }
    }

    private fun onClicked(event: AccessibilityEvent) {
        if (!prefs.frictionOn) return
        val desc = event.contentDescription?.toString() ?: event.source?.contentDescription?.toString() ?: return
        if (InstagramScreens.ENGAGEMENT_DESCRIPTION.containsMatchIn(desc) && state.sincePx > 0) {
            // Actually engaging with a post, not just flicking past: ease the counter.
            state.sincePx /= 2
            saveSoon(SystemClock.elapsedRealtime())
        }
    }

    /* --------------------------------- screen state --------------------------------- */

    private fun refreshScreen(now: Long, force: Boolean): Screen {
        if (!force && now - cachedAt < SCREEN_CACHE_MS) return cachedScreen
        val root = rootInActiveWindow ?: return cachedScreen
        try {
            if (root.packageName?.toString() == InstagramScreens.PACKAGE) {
                cachedScreen = InstagramScreens.detect(root)
                cachedAt = now
                if (prefs.debugLog && cachedScreen != lastLoggedScreen) {
                    Log.d(TAG, "screen -> $cachedScreen")
                    lastLoggedScreen = cachedScreen
                }
            }
        } finally {
            InstagramScreens.recycleCompat(root)
        }
        return cachedScreen
    }

    /** Called after every Instagram event. Applies whichever rule fits the screen that is showing. */
    private fun applyScreenRules(now: Long) {
        when (cachedScreen) {
            Screen.FEED, Screen.EXPLORE -> {
                reelsSession = false
                applyFeedRules()
            }
            Screen.REELS -> {
                overlay.hideBanner()
                if (prefs.frictionOn && state.pauseUntil > 0L) {
                    showPause()
                } else {
                    overlay.hideFullUnlessReelBlock()
                    onReelsEntered(now)
                }
            }
            Screen.MESSAGES -> {
                reelsSession = false
                overlay.hideBanner()
                overlay.hideFullUnlessReelBlock()
            }
            Screen.OTHER -> overlay.hideBanner() // profile, settings, unknown: leave any cover screen alone
        }
    }

    private fun applyFeedRules() {
        if (!prefs.frictionOn && state.pauseUntil > 0L) {
            state.pauseUntil = 0L
            state.save()
        }
        val capHit = prefs.dailyCapOn && state.todayPx >= capPx()
        when {
            prefs.frictionOn && state.pauseUntil > 0L -> showPause()
            capHit && SystemClock.elapsedRealtime() >= suppressCapUntil -> showCap()
            else -> {
                overlay.hideFullUnlessReelBlock()
                updateBanner()
            }
        }
        if (overlay.kind == OverlayHost.Kind.PAUSE || overlay.kind == OverlayHost.Kind.CAP) overlay.hideBanner()
    }

    private fun updateBanner() {
        if (prefs.frictionOn && state.sincePx >= nudgePx()) {
            val screens = (state.sincePx / screenH).toInt()
            overlay.showBanner("$screens screens scrolled. A pause comes at ${prefs.pauseScreens}.")
        } else {
            overlay.hideBanner()
        }
    }

    /* ---------------------------- finite feed + friction ---------------------------- */

    private fun capPx(): Long = prefs.dailyScreens.toLong() * screenH
    private fun nudgePx(): Long = prefs.nudgeScreens.toLong() * screenH
    private fun pausePx(): Long = max(prefs.pauseScreens, prefs.nudgeScreens + 1).toLong() * screenH

    private fun addScroll(dy: Int, now: Long) {
        if (!prefs.frictionOn && !prefs.dailyCapOn) return
        val d = min(dy, 2000).toLong()
        state.todayPx += d
        state.sincePx += d
        if (prefs.frictionOn && state.pauseUntil == 0L && state.sincePx >= pausePx()) startPause()
        saveSoon(now)
    }

    private fun startPause() {
        state.pauses += 1
        val seconds = prefs.pauseSeconds * min(max(state.pauses, 1), 4)
        state.pauseUntil = System.currentTimeMillis() + seconds * 1000L
        state.save()
    }

    private fun endPause() {
        state.pauseUntil = 0L
        state.sincePx = 0L
        state.save()
        overlay.hideFull()
        overlay.hideBanner()
    }

    private fun showPause() {
        overlay.showPause(
            pauseUntil = { state.pauseUntil },
            pauseSeconds = prefs.pauseSeconds,
            onContinue = { endPause() },
            onLeave = { goHome() }
        )
    }

    private fun showCap() {
        overlay.showCap(
            screens = prefs.dailyScreens,
            onLeave = { goHome() },
            onMessages = { openMessages() }
        )
    }

    private fun goHome() {
        overlay.hideAll()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun openMessages() {
        // Give the cover screen a few seconds of grace so the app can switch to the inbox.
        suppressCapUntil = SystemClock.elapsedRealtime() + 4000L
        overlay.hideAll()
        val root = rootInActiveWindow ?: return
        try {
            InstagramScreens.clickInbox(root)
        } finally {
            InstagramScreens.recycleCompat(root)
        }
    }

    /* ------------------------------------ Reels ------------------------------------ */

    private fun onReelsEntered(now: Long) {
        if (!prefs.reelsOn || reelsSession) return
        reelsSession = true
        reelsEnteredAt = now
        reelsSwipePx = 0L
        reelsLastScrollAt = 0L
        if (state.reelVisits >= prefs.reelsPerDay) {
            blockReels("Reels are limited to ${prefs.reelsPerDay} per day, and you've used ${if (prefs.reelsPerDay == 1) "it" else "them"}.", now)
        } else {
            state.reelVisits += 1
            state.save()
        }
    }

    private fun onReelsScroll(event: AccessibilityEvent, dy: Int, now: Long) {
        if (!prefs.reelsOn || !reelsSession) return
        if (now - reelsEnteredAt < REELS_GRACE_MS) return // the first Reel loading can fire scroll events

        val id = event.source?.viewIdResourceName
        if (id != null && InstagramScreens.REELS_SCROLL_IGNORE_ID_PARTS.any { id.contains(it, ignoreCase = true) }) return

        if (now - reelsLastScrollAt > 800L) reelsSwipePx = 0L
        reelsLastScrollAt = now
        reelsSwipePx += min(dy, 2000)
        if (reelsSwipePx >= screenH * 0.2) {
            blockReels("That was today's Reel. The next one won't play.", now)
        }
    }

    private fun blockReels(message: String, now: Long) {
        if (now - lastReelBlockAt < REEL_BLOCK_GAP_MS) return
        lastReelBlockAt = now
        reelsSession = false
        reelsSwipePx = 0L
        overlay.showReelBlock(message)

        // Step back out. Prefer tapping the Home tab; if the tab bar is hidden, press Back once.
        val root = rootInActiveWindow
        var done = false
        if (root != null) {
            try {
                done = InstagramScreens.clickHomeTab(root)
            } finally {
                InstagramScreens.recycleCompat(root)
            }
        }
        if (!done) performGlobalAction(GLOBAL_ACTION_BACK)
        cachedAt = 0L
    }

    /* ------------------------------ leaving Instagram ------------------------------ */

    private fun checkLeftInstagram() {
        val root = rootInActiveWindow ?: return
        val active = try { root.packageName?.toString() } finally { InstagramScreens.recycleCompat(root) }
        if (active != null && active != InstagramScreens.PACKAGE && active != packageName) {
            leaveInstagram()
        }
    }

    private fun leaveInstagram() {
        if (::overlay.isInitialized) overlay.hideAll()
        reelsSession = false
        cachedScreen = Screen.OTHER
        cachedAt = 0L
        lastLoggedScreen = null
        if (::state.isInitialized) state.save()
    }

    /* ------------------------------------ misc ------------------------------------ */

    private fun saveSoon(now: Long) {
        if (now - lastSaveAt < SAVE_EVERY_MS) return
        lastSaveAt = now
        state.save()
    }

    private fun dumpIdsToLog() {
        val root = rootInActiveWindow ?: return
        try {
            if (root.packageName?.toString() == InstagramScreens.PACKAGE) {
                Log.d(TAG, "ids: " + InstagramScreens.dumpIds(root).take(150).joinToString(", "))
            }
        } finally {
            InstagramScreens.recycleCompat(root)
        }
    }

    companion object {
        private const val TAG = "DSB"
        private const val SCREEN_CACHE_MS = 600L
        private const val SAVE_EVERY_MS = 2000L
        private const val REELS_GRACE_MS = 1500L
        private const val REEL_BLOCK_GAP_MS = 1200L
    }
}
