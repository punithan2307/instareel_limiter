package app.doomscrollbrake

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Draws the full-screen pause / limit screens and the small nudge banner on top of Instagram.
 * Uses TYPE_ACCESSIBILITY_OVERLAY, which an enabled accessibility service may use without any extra
 * "draw over other apps" permission.
 */
class OverlayHost(private val service: AccessibilityService) {

    enum class Kind { PAUSE, CAP, REEL_BLOCK }

    private val wm = service.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var full: View? = null
    var kind: Kind? = null
        private set
    private var banner: TextView? = null
    private var countdownTick: Runnable? = null
    private var autoHide: Runnable? = null

    /* ------------------------------ full-screen screens ------------------------------ */

    fun showPause(pauseUntil: () -> Long, pauseSeconds: Int, onContinue: () -> Unit, onLeave: () -> Unit) {
        if (kind == Kind.PAUSE) return
        val count = TextView(service)
        count.textSize = 64f
        count.setTextColor(Color.WHITE)
        count.gravity = Gravity.CENTER
        count.typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)

        val keep = Ui.button(service, "Keep scrolling", true, onContinue)
        keep.isEnabled = false
        keep.alpha = 0.35f

        val view = panel(
            title = "Pause. You've been scrolling a while.",
            body = "Look away from the screen for a moment. What did you open Instagram for?",
            middle = count,
            buttons = listOf(keep, Ui.button(service, "Leave Instagram", false, onLeave))
        )
        show(Kind.PAUSE, view)

        val tick = object : Runnable {
            override fun run() {
                val left = Math.max(0L, (pauseUntil() - System.currentTimeMillis() + 999L) / 1000L)
                count.text = left.toString()
                if (left == 0L && !keep.isEnabled) {
                    keep.isEnabled = true
                    keep.alpha = 1f
                }
                handler.postDelayed(this, 250L)
            }
        }
        countdownTick = tick
        tick.run()
    }

    fun showCap(screens: Int, onLeave: () -> Unit, onMessages: () -> Unit) {
        if (kind == Kind.CAP) return
        val view = panel(
            title = "You're all caught up",
            body = "You've used today's scroll budget (about $screens screens). Fresh posts will be here tomorrow.",
            middle = null,
            buttons = listOf(
                Ui.button(service, "Leave Instagram", true, onLeave),
                Ui.button(service, "Open messages", false, onMessages)
            )
        )
        show(Kind.CAP, view)
    }

    /** Short screen shown while the app steps back out of the Reels viewer. Hides itself. */
    fun showReelBlock(message: String) {
        if (kind == Kind.REEL_BLOCK) return
        val view = panel(
            title = "That's your Reel.",
            body = message,
            middle = null,
            buttons = emptyList()
        )
        show(Kind.REEL_BLOCK, view)
        val hide = Runnable { if (kind == Kind.REEL_BLOCK) hideFull() }
        autoHide = hide
        handler.postDelayed(hide, 2500L)
    }

    fun hideFull() {
        countdownTick?.let { handler.removeCallbacks(it) }
        countdownTick = null
        autoHide?.let { handler.removeCallbacks(it) }
        autoHide = null
        val v = full
        if (v != null) {
            try {
                wm.removeViewImmediate(v)
            } catch (_: Exception) {
                // Already gone.
            }
        }
        full = null
        kind = null
    }

    /** Hides pause/limit screens but leaves the short Reel screen to finish on its own. */
    fun hideFullUnlessReelBlock() {
        if (kind != Kind.REEL_BLOCK) hideFull()
    }

    private fun show(newKind: Kind, view: View) {
        hideFull()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, params)
            full = view
            kind = newKind
        } catch (_: Exception) {
            full = null
            kind = null
        }
    }

    private fun panel(title: String, body: String, middle: View?, buttons: List<View>): View {
        val root = FrameLayout(service)
        root.setBackgroundColor(Color.argb(245, 10, 10, 12))
        root.isClickable = true // swallow every touch so Instagram underneath cannot be scrolled
        root.isFocusable = true

        val col = LinearLayout(service)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val pad = Ui.dp(service, 28)
        col.setPadding(pad, pad, pad, pad)

        val eyebrow = TextView(service)
        eyebrow.text = "DOOMSCROLL BRAKE"
        eyebrow.textSize = 11f
        eyebrow.letterSpacing = 0.14f
        eyebrow.setTextColor(Color.argb(140, 255, 255, 255))
        eyebrow.gravity = Gravity.CENTER
        col.addView(eyebrow, lp(bottomDp = 16))

        val titleView = TextView(service)
        titleView.text = title
        titleView.textSize = 24f
        titleView.setTextColor(Color.WHITE)
        titleView.gravity = Gravity.CENTER
        col.addView(titleView, lp(bottomDp = 12))

        if (middle != null) col.addView(middle, lp(bottomDp = 12))

        val bodyView = TextView(service)
        bodyView.text = body
        bodyView.textSize = 16f
        bodyView.setTextColor(Color.argb(190, 255, 255, 255))
        bodyView.gravity = Gravity.CENTER
        col.addView(bodyView, lp(bottomDp = 28))

        for (b in buttons) col.addView(b, lp(bottomDp = 10))

        val frame = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        root.addView(col, frame)
        return root
    }

    private fun lp(bottomDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.bottomMargin = Ui.dp(service, bottomDp)
        return p
    }

    /* --------------------------------- nudge banner --------------------------------- */

    /** Small, non-touchable banner near the top that shows how far you have scrolled. */
    fun showBanner(text: String) {
        val existing = banner
        if (existing != null) {
            if (existing.text.toString() != text) existing.text = text
            return
        }
        val t = TextView(service)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        val h = Ui.dp(service, 16)
        val v = Ui.dp(service, 8)
        t.setPadding(h, v, h, v)
        t.background = Ui.rounded(service, Color.argb(225, 20, 20, 22), 999)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = Ui.dp(service, 96)
        try {
            wm.addView(t, params)
            banner = t
        } catch (_: Exception) {
            banner = null
        }
    }

    fun hideBanner() {
        val b = banner ?: return
        try {
            wm.removeViewImmediate(b)
        } catch (_: Exception) {
            // Already gone.
        }
        banner = null
    }

    fun hideAll() {
        hideFull()
        hideBanner()
    }
}
