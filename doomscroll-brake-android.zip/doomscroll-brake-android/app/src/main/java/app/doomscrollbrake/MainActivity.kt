package app.doomscrollbrake

import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.AccessibilityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Settings screen. No XML layouts—everything is built in code so the app stays tiny and has no theme
 * dependencies. Shows on-off switches for each feature, numeric limits, today's counts, and buttons to
 * open the Android accessibility settings (where the service must be enabled) and to reset today.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var state: DayState

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        state = DayState.get(this)

        setContentView(ScrollView(this).apply {
            addView(buildUi())
        })
        checkAccessibility()
    }

    override fun onResume() {
        super.onResume()
        state.rolloverIfNeeded()
        checkAccessibility()
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 20)
        root.setPadding(pad, pad, pad, pad)

        root.addView(h2("Doomscroll Brake for Instagram"))

        // Status
        root.addView(section("Today") {
            addView(stat("Posts scrolled", "${(state.todayPx / 800).toInt()} screens"))
            addView(stat("Reels seen", "${state.reelVisits}"))
            addView(stat("Pauses", "${state.pauses}"))
            addView(h3("").apply { layoutParams = LinearLayout.LayoutParams(-1, Ui.dp(this@MainActivity, 8)) })
            addView(Button(this@MainActivity).apply {
                text = "Reset today"
                setOnClickListener { state.resetToday(); checkAccessibility() }
            })
        })

        root.addView(section("Enabled") {
            addView(toggle("Turn everything on or off", "enabled") { prefs.enabled = it })
        })

        root.addView(section("Finite feed") {
            addView(toggle("Hide the rest of Home after your daily scroll budget", "dailyCapOn") { prefs.dailyCapOn = it })
            addView(spinner("Screens per day", "dailyScreens", 5, 500) { prefs.dailyScreens = it })
        })

        root.addView(section("Scroll friction") {
            addView(toggle("Show a banner, then a countdown pause", "frictionOn") { prefs.frictionOn = it })
            addView(spinner("Nudge banner after (screens)", "nudgeScreens", 1, 50) { prefs.nudgeScreens = it })
            addView(spinner("Pause after (screens)", "pauseScreens", 2, 100) { prefs.pauseScreens = it })
            addView(spinner("First pause length (seconds)", "pauseSeconds", 5, 300) { prefs.pauseSeconds = it })
        })

        root.addView(section("One Reel at a time") {
            addView(toggle("No next Reel after the one you opened", "reelsOn") { prefs.reelsOn = it })
            addView(spinner("Reels per day", "reelsPerDay", 1, 20) { prefs.reelsPerDay = it })
        })

        root.addView(section("Debug") {
            addView(toggle("Write what I see to logcat (for troubleshooting)", "debugLog") { prefs.debugLog = it })
        })

        root.addView(h3("Accessibility Service Status"))
        val status = TextView(this)
        status.textSize = 14f
        status.setTextColor(0xFF333333.toInt())
        root.addView(status)

        val openA11y = Button(this).apply {
            text = "Open Android Accessibility Settings"
            setOnClickListener { startActivityForResult(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), 0) }
        }
        root.addView(openA11y)

        // Update status on first draw and when resumed
        fun updateStatus() {
            val isEnabled = isServiceEnabled()
            status.text = if (isEnabled) "✓ Service is enabled" else "✗ Service is disabled"
            status.setTextColor(if (isEnabled) 0xFF22A45D.toInt() else 0xFFCC3333.toInt())
        }
        root.post { updateStatus() }
        this@MainActivity.registerActivityResultListener { _, _, _ -> updateStatus() }

        return root
    }

    private fun section(title: String, build: LinearLayout.() -> Unit): LinearLayout {
        val s = LinearLayout(this)
        s.orientation = LinearLayout.VERTICAL
        s.layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = Ui.dp(this@MainActivity, 20)
        }
        s.addView(h3(title))
        build(s)
        return s
    }

    private fun h2(text: String) = TextView(this).apply {
        this.text = text
        textSize = 24f
        setTextColor(0xFF111111.toInt())
    }

    private fun h3(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(0xFF555555.toInt())
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MainActivity, 12) }
    }

    private fun stat(label: String, value: String): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MainActivity, 8) }
        row.addView(TextView(this).apply {
            text = label
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        row.addView(TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(0xFF111111.toInt())
            setTypeface(android.graphics.Typeface.MONOSPACE)
        })
        return row
    }

    private fun toggle(label: String, prefKey: String, onChange: (Boolean) -> Unit): CheckBox {
        val cb = CheckBox(this)
        cb.text = label
        cb.textSize = 14f
        cb.isChecked = when (prefKey) {
            "enabled" -> prefs.enabled
            "dailyCapOn" -> prefs.dailyCapOn
            "frictionOn" -> prefs.frictionOn
            "reelsOn" -> prefs.reelsOn
            "debugLog" -> prefs.debugLog
            else -> false
        }
        cb.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        cb.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this, 8) }
        return cb
    }

    private fun spinner(label: String, prefKey: String, min: Int, max: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this, 8) }
        val lbl = TextView(this)
        lbl.text = label
        lbl.textSize = 14f
        lbl.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        row.addView(lbl)

        val current = when (prefKey) {
            "dailyScreens" -> prefs.dailyScreens
            "nudgeScreens" -> prefs.nudgeScreens
            "pauseScreens" -> prefs.pauseScreens
            "pauseSeconds" -> prefs.pauseSeconds
            "reelsPerDay" -> prefs.reelsPerDay
            else -> min
        }

        val et = EditText(this)
        et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        et.setText(current.toString())
        et.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 80), -2)
        et.gravity = Gravity.END
        et.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val v = et.text.toString().toIntOrNull() ?: current
                val clamped = v.coerceIn(min, max)
                et.setText(clamped.toString())
                onChange(clamped)
            }
        }
        row.addView(et)
        return row
    }

    private fun isServiceEnabled(): Boolean {
        val am = getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val services = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return services.any { it.id.contains(packageName) }
    }

    private fun checkAccessibility() {
        // Show a warning if the service is not enabled.
        if (!isServiceEnabled()) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            // Could optionally show an unobtrusive banner here instead of opening settings.
        }
    }

    private fun registerActivityResultListener(listener: (Int, Int, Intent?) -> Unit) {
        // For API < 31, we can use onActivityResult; for 31+, use registerForActivityResult.
        // This is a simplified version that just re-checks on resume.
    }
}
