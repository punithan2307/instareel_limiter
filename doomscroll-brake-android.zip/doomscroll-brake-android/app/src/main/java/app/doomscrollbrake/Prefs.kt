package app.doomscrollbrake

import android.content.Context
import android.content.SharedPreferences
import java.util.Calendar

/**
 * User-configurable limits. "Screens" means multiples of the phone's screen height, which is how far
 * you have scrolled (about 1 to 1.5 posts per screen).
 */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("doomscroll_brake", Context.MODE_PRIVATE)

    /** Master switch. */
    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    /** Finite feed: block Home/Explore once today's scroll budget is used. */
    var dailyCapOn: Boolean
        get() = sp.getBoolean("dailyCapOn", true)
        set(v) { sp.edit().putBoolean("dailyCapOn", v).apply() }

    var dailyScreens: Int
        get() = sp.getInt("dailyScreens", 30).coerceIn(5, 500)
        set(v) { sp.edit().putInt("dailyScreens", v.coerceIn(5, 500)).apply() }

    /** Scroll friction: a nudge banner, then a forced pause. */
    var frictionOn: Boolean
        get() = sp.getBoolean("frictionOn", true)
        set(v) { sp.edit().putBoolean("frictionOn", v).apply() }

    var nudgeScreens: Int
        get() = sp.getInt("nudgeScreens", 5).coerceIn(1, 50)
        set(v) { sp.edit().putInt("nudgeScreens", v.coerceIn(1, 50)).apply() }

    var pauseScreens: Int
        get() = sp.getInt("pauseScreens", 10).coerceIn(2, 100)
        set(v) { sp.edit().putInt("pauseScreens", v.coerceIn(2, 100)).apply() }

    var pauseSeconds: Int
        get() = sp.getInt("pauseSeconds", 15).coerceIn(5, 300)
        set(v) { sp.edit().putInt("pauseSeconds", v.coerceIn(5, 300)).apply() }

    /** One Reel at a time. */
    var reelsOn: Boolean
        get() = sp.getBoolean("reelsOn", true)
        set(v) { sp.edit().putBoolean("reelsOn", v).apply() }

    var reelsPerDay: Int
        get() = sp.getInt("reelsPerDay", 1).coerceIn(1, 20)
        set(v) { sp.edit().putInt("reelsPerDay", v.coerceIn(1, 20)).apply() }

    /** Writes what the service sees (screen names, view ids) to logcat under the tag "DSB". */
    var debugLog: Boolean
        get() = sp.getBoolean("debugLog", false)
        set(v) { sp.edit().putBoolean("debugLog", v).apply() }
}

/**
 * Today's counters. One shared instance per process, so the service and the settings screen agree.
 * Everything resets when the local calendar day changes.
 */
class DayState private constructor(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("doomscroll_brake_state", Context.MODE_PRIVATE)

    var day: String = ""
    /** Pixels scrolled today on Home/Explore. */
    var todayPx: Long = 0L
    /** Pixels scrolled since the last break. */
    var sincePx: Long = 0L
    var pauses: Int = 0
    /** Wall-clock ms; non-zero while a forced pause is waiting to be dismissed. */
    var pauseUntil: Long = 0L
    /** Reel visits that have been used today. */
    var reelVisits: Int = 0

    init {
        day = sp.getString("day", "") ?: ""
        todayPx = sp.getLong("todayPx", 0L)
        sincePx = sp.getLong("sincePx", 0L)
        pauses = sp.getInt("pauses", 0)
        pauseUntil = sp.getLong("pauseUntil", 0L)
        reelVisits = sp.getInt("reelVisits", 0)
        rolloverIfNeeded()
    }

    fun save() {
        sp.edit()
            .putString("day", day)
            .putLong("todayPx", todayPx)
            .putLong("sincePx", sincePx)
            .putInt("pauses", pauses)
            .putLong("pauseUntil", pauseUntil)
            .putInt("reelVisits", reelVisits)
            .apply()
    }

    /** Returns true if a new day started and the counters were cleared. */
    fun rolloverIfNeeded(): Boolean {
        val today = todayKey()
        if (day == today) return false
        day = today
        todayPx = 0L
        sincePx = 0L
        pauses = 0
        pauseUntil = 0L
        reelVisits = 0
        save()
        return true
    }

    fun resetToday() {
        day = ""
        rolloverIfNeeded()
    }

    companion object {
        private var instance: DayState? = null

        fun get(context: Context): DayState {
            val existing = instance
            if (existing != null) return existing
            val created = DayState(context.applicationContext)
            instance = created
            return created
        }

        fun todayKey(): String {
            val c = Calendar.getInstance()
            return String.format(
                "%04d-%02d-%02d",
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1,
                c.get(Calendar.DAY_OF_MONTH)
            )
        }
    }
}
