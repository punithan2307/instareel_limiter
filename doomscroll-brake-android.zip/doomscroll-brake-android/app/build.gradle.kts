plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.doomscrollbrake"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.doomscrollbrake"
        minSdk = 28 // AccessibilityEvent.getScrollDeltaY() needs API 28 (Android 9)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// No third-party dependencies on purpose: plain Android framework classes only.
dependencies {
}
