/*
 * Doomscroll Brake — content script for instagram.com
 *
 * 1. Finite feed      Home feed is capped at N distinct posts per day, then an "all caught up" card.
 * 2. Scroll friction  Scrolling gets heavier the longer you go without engaging, then a forced pause.
 * 3. One Reel         The Reels viewer never advances to a next Reel; extra Reels are hidden/blocked.
 *
 * Instagram changes its markup often. Everything that depends on it lives in SELECTORS below.
 */
(() => {
  'use strict';
  if (globalThis.__dsbLoaded) return;
  globalThis.__dsbLoaded = true;

  const { DEFAULTS, sanitize, todayKey, blankState } = globalThis.DSB;
  const api = globalThis.browser ?? globalThis.chrome;

  /* ------------------------------------------------------------------ */
  /* Instagram-specific selectors — edit here if Instagram changes.     */
  /* ------------------------------------------------------------------ */
  const SELECTORS = {
    feedPost: 'main article',
    postLink: 'a[href*="/p/"], a[href*="/reel/"]',
    reelLink: 'a[href*="/reel/"]',
    reelNav: ['button[aria-label*="Navigate" i]', '[role="button"][aria-label*="Navigate" i]'],
    loadingSpinner: ['[role="progressbar"]', 'svg[aria-label="Loading..."]'],
  };
  // Like / comment / share / save count as "engaging", which eases the scroll counter. English UI only.
  const ENGAGEMENT_LABEL = /^(like|unlike|comment|share|save|remove)\b/i;
  const MIN_FACTOR = 0.2; // heaviest scroll friction: 20% of normal speed

  /* ------------------------------------------------------------------ */
  /* Small helpers                                                      */
  /* ------------------------------------------------------------------ */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function h(tag, props = {}, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    node.append(...kids);
    return node;
  }

  const alive = () => {
    try { return !!api.runtime?.id; } catch { return false; }
  };
  const store = {
    async get(area, defaults) {
      try { return await api.storage[area].get(defaults); } catch { return defaults; }
    },
    set(area, obj) {
      try { return Promise.resolve(api.storage[area].set(obj)).catch(() => {}); } catch { return Promise.resolve(); }
    },
  };

  const root = document.documentElement;
  const screenPx = () => Math.max(600, window.innerHeight || 800);
  const isTyping = (el) =>
    el instanceof Element && (el.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]') !== null);

  /* ------------------------------------------------------------------ */
  /* State                                                              */
  /* ------------------------------------------------------------------ */
  let settings = sanitize(DEFAULTS);
  let state = blankState();
  const seenPosts = new Set();
  const seenReels = new Set();
  let accum = 0; // px scrolled since last break

  const serialize = () => ({
    ...state,
    posts: [...seenPosts].slice(-1000),
    reels: [...seenReels].slice(-200),
    scrollPx: Math.round(accum),
  });

  function hydrate(src) {
    const s = src && src.day === todayKey() ? src : blankState();
    state = { ...blankState(), ...s };
    seenPosts.clear();
    (s.posts || []).forEach((k) => seenPosts.add(k));
    seenReels.clear();
    (s.reels || []).forEach((k) => seenReels.add(k));
    accum = Number(s.scrollPx) || 0;
  }

  let saveTimer = null;
  function scheduleSave() {
    if (saveTimer) return;
    saveTimer = setTimeout(() => {
      saveTimer = null;
      if (alive()) store.set('local', { dsbState: serialize() });
    }, 400);
  }

  function rolloverIfNeeded() {
    if (state.day !== todayKey()) {
      hydrate(null);
      scheduleSave();
    }
  }

  /* ------------------------------------------------------------------ */
  /* Page type helpers                                                  */
  /* ------------------------------------------------------------------ */
  const isHome = () => location.pathname === '/';
  const frictionPage = () => isHome() || location.pathname.startsWith('/explore');

  // Returns { code } when the current URL is a Reels viewer, otherwise null.
  function viewerInfo() {
    const p = location.pathname;
    let m = p.match(/^\/reels?\/(?!audio(?:\/|$))([\w-]+)\/?/);
    if (m) return { code: m[1] };
    m = p.match(/^\/[\w.]+\/reel\/([\w-]+)/);
    if (m) return { code: m[1] };
    if (/^\/reels\/?$/.test(p)) return { code: null };
    return null;
  }

  function postKey(article) {
    const a = article.querySelector(SELECTORS.postLink);
    const m = a && (a.getAttribute('href') || '').match(/\/(?:p|reel)\/([\w-]+)/);
    return m ? m[1] : null;
  }
  const isReelArticle = (article) => article.querySelector(SELECTORS.reelLink) !== null;
  const postsExhausted = () => settings.feedCapOn && seenPosts.size >= settings.postsPerDay;

  /* ------------------------------------------------------------------ */
  /* 1. Finite feed (+ hiding extra Reels in the feed)                  */
  /* ------------------------------------------------------------------ */
  const visible = new Set();
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) (e.isIntersecting ? visible.add(e.target) : visible.delete(e.target));
      schedule();
    },
    { threshold: [0.4] }
  );

  function markSeen(article) {
    const key = postKey(article);
    if (!key) return false;
    let changed = false;
    if (settings.reelsOn && isReelArticle(article) && !seenReels.has(key) && seenReels.size < settings.reelsPerDay) {
      seenReels.add(key);
      changed = true;
    }
    if (!seenPosts.has(key) && !postsExhausted()) {
      seenPosts.add(key);
      changed = true;
    }
    return changed;
  }

  function setHidden(article, reason) {
    if (reason) {
      if (article.dataset.dsbHidden !== reason) article.dataset.dsbHidden = reason;
    } else if (article.hasAttribute('data-dsb-hidden')) {
      article.removeAttribute('data-dsb-hidden');
    }
  }

  function buildCard() {
    return h(
      'div',
      { id: 'dsb-card', class: 'dsb-card' },
      h('h3', { text: "You're all caught up" }),
      h('p', { class: 'dsb-card-text', text: '' }),
      h('a', { href: '/direct/inbox/', text: 'Message a friend instead' })
    );
  }

  function placeCard(anchor, articles) {
    let card = document.getElementById('dsb-card');
    if (!card) card = buildCard();
    const text = `You've seen ${seenPosts.size} posts today. Fresh ones will be waiting tomorrow.`;
    const p = $('.dsb-card-text', card);
    if (p && p.textContent !== text) p.textContent = text;

    if (anchor && anchor.parentElement) {
      if (card.nextElementSibling !== anchor || card.parentElement !== anchor.parentElement) {
        anchor.parentElement.insertBefore(card, anchor);
      }
    } else if (articles.length) {
      const last = articles[articles.length - 1];
      if (last.nextElementSibling !== card) last.after(card);
    }
  }
  const removeCard = () => document.getElementById('dsb-card')?.remove();

  function processFeed() {
    if (!isHome()) {
      removeCard();
      return;
    }
    const articles = $$(SELECTORS.feedPost);
    articles.forEach((a) => io.observe(a));

    // 1) count what is on screen right now
    let changed = false;
    for (const a of Array.from(visible)) {
      if (!a.isConnected) { visible.delete(a); continue; }
      if (a.hasAttribute('data-dsb-hidden')) continue;
      if (markSeen(a)) changed = true;
    }
    if (changed) scheduleSave();

    // 2) hide what is over budget
    let firstCapHidden = null;
    for (const a of articles) {
      const key = postKey(a);
      let reason = null;
      if (settings.reelsOn && isReelArticle(a) && !(key && seenReels.has(key)) && seenReels.size >= settings.reelsPerDay) {
        reason = 'reel';
      } else if (postsExhausted() && !(key && seenPosts.has(key))) {
        reason = 'cap';
      }
      setHidden(a, reason);
      if (reason === 'cap' && !firstCapHidden) firstCapHidden = a;
    }

    if (postsExhausted()) placeCard(firstCapHidden, articles);
    else removeCard();
  }

  /* ------------------------------------------------------------------ */
  /* 2. Scroll friction + forced pause                                  */
  /* ------------------------------------------------------------------ */
  const pauseActive = () => state.pauseUntil > 0;
  const frictionTracking = () => settings.enabled && settings.frictionOn && frictionPage() && !pauseActive();
  const startPx = () => settings.frictionStartScreens * screenPx();
  const pausePx = () => settings.pauseAfterScreens * screenPx();

  function frictionFactor() {
    const s = startPx();
    if (accum <= s) return 1;
    const t = Math.min(1, (accum - s) / Math.max(1, pausePx() - s));
    return 1 - t * (1 - MIN_FACTOR);
  }

  function addScroll(px) {
    accum += px;
    scheduleSave();
    if (accum >= pausePx()) startPause();
  }

  const pauseLength = (n) => settings.pauseSeconds * Math.min(Math.max(n, 1), 4);

  function startPause(remainingMs) {
    if (pauseActive()) return;
    state.pauses += 1;
    const ms = remainingMs ?? pauseLength(state.pauses) * 1000;
    state.pauseUntil = Date.now() + ms;
    scheduleSave();
    syncOverlays();
  }

  function endPause() {
    state.pauseUntil = 0;
    accum = 0;
    scheduleSave();
    syncOverlays();
  }

  const lastTop = new WeakMap();
  const scrollingEl = () => document.scrollingElement || root;

  function onScroll(e) {
    const t = e.target === document ? scrollingEl() : e.target;
    if (!(t instanceof Element)) return;
    const top = t.scrollTop;
    const prev = lastTop.get(t);
    lastTop.set(t, top);
    if (prev == null || !frictionTracking()) return;
    const d = Math.abs(top - prev);
    if (d > 0) addScroll(Math.min(d, 2000));
  }

  function scrollableAncestor(el) {
    for (let n = el instanceof Element ? el : null; n && n !== document.body && n !== root; n = n.parentElement) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 1) return n;
    }
    return scrollingEl();
  }

  const inOverlay = (el) => el instanceof Element && el.closest('#dsb-overlay') !== null;
  const reelLockActive = () => root.classList.contains('dsb-reel-lock');
  const scrollLocked = () => overlayKind !== null || reelLockActive();

  function onWheel(e) {
    if (e.ctrlKey) return; // pinch zoom
    if (scrollLocked()) {
      if (!inOverlay(e.target)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
      return;
    }
    if (!frictionTracking() || Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
    const f = frictionFactor();
    if (f > 0.98) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight : 1;
    scrollableAncestor(e.target).scrollBy({ top: e.deltaY * unit * f, behavior: 'instant' });
  }

  function onTouchMove(e) {
    if (scrollLocked() && !inOverlay(e.target)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }

  const LOCK_KEYS = new Set(['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', 'End', 'Home']);
  function onKeyDown(e) {
    if (isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (scrollLocked()) {
      if (LOCK_KEYS.has(e.key) || (overlayKind && e.key === ' ')) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
      return;
    }
    if (!frictionTracking()) return;
    const f = frictionFactor();
    if (f > 0.98) return;
    const page = window.innerHeight * 0.9;
    const dy = { ArrowDown: 60, ArrowUp: -60, PageDown: page, PageUp: -page, End: page }[e.key];
    if (dy === undefined) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    scrollableAncestor(e.target).scrollBy({ top: dy * f, behavior: 'instant' });
  }

  function onClick(e) {
    const t = e.target instanceof Element ? e.target : null;
    if (!t) return;
    // Block the "next/previous Reel" arrows while the Reels viewer is locked.
    if (reelLockActive() && t.closest(SELECTORS.reelNav.join(','))) {
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    // Engaging with a post (like, comment, share, save) eases the counter.
    if (frictionTracking() && t.closest('article')) {
      const labelled = t.closest('[aria-label]');
      if (labelled && ENGAGEMENT_LABEL.test(labelled.getAttribute('aria-label') || '')) {
        accum = Math.floor(accum * 0.5);
        scheduleSave();
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* 3. One Reel at a time (viewer lock, daily allowance)               */
  /* ------------------------------------------------------------------ */
  let dwellTimer = null;
  let dwellHref = null;
  const clearDwell = () => {
    clearTimeout(dwellTimer);
    dwellTimer = null;
    dwellHref = null;
  };

  function watchReelDwell() {
    const v = settings.enabled && settings.reelsOn ? viewerInfo() : null;
    if (!v || overlayKind) {
      clearDwell();
      return;
    }
    if (dwellHref === location.href) return;
    clearDwell();
    dwellHref = location.href;
    dwellTimer = setTimeout(() => {
      dwellTimer = null;
      const cur = viewerInfo();
      if (!cur || overlayKind) return;
      const key = cur.code || '__reels_root__';
      if (!seenReels.has(key)) {
        seenReels.add(key);
        scheduleSave();
        schedule();
      }
    }, 1800);
  }

  /* ------------------------------------------------------------------ */
  /* Overlays (forced pause, blocked Reel) and the one-Reel pill        */
  /* ------------------------------------------------------------------ */
  let overlayKind = null; // 'pause' | 'reel' | null
  let overlayTimer = null;

  function pauseMedia() {
    $$('video').forEach((v) => {
      try { v.pause(); } catch { /* ignore */ }
    });
  }

  function unmountOverlay() {
    clearInterval(overlayTimer);
    overlayTimer = null;
    document.getElementById('dsb-overlay')?.remove();
    overlayKind = null;
    root.classList.remove('dsb-locked');
  }

  function mountOverlay(kind) {
    unmountOverlay();
    overlayKind = kind;
    root.classList.add('dsb-locked');
    pauseMedia();

    const panel = h('div', { class: 'dsb-panel' }, h('p', { class: 'dsb-eyebrow', text: 'Doomscroll Brake' }));
    const msg = h('a', { class: 'dsb-btn', href: '/direct/inbox/', text: 'Message a friend' });

    if (kind === 'pause') {
      const count = h('div', { class: 'dsb-count', text: '' });
      const cont = h('button', { class: 'dsb-btn dsb-primary', type: 'button', disabled: '', text: 'Keep scrolling', onclick: endPause });
      const done = h('button', { class: 'dsb-btn', type: 'button', text: "I'm done", onclick: () => { location.href = 'about:blank'; } });
      panel.append(
        h('h2', { class: 'dsb-title', text: "Pause. You've been scrolling a while." }),
        count,
        h('p', { class: 'dsb-body', text: 'Look away from the screen for a moment. What did you open Instagram for?' }),
        h('div', { class: 'dsb-actions' }, cont, msg, done)
      );
      const update = () => {
        const left = Math.max(0, Math.ceil((state.pauseUntil - Date.now()) / 1000));
        count.textContent = left > 0 ? String(left) : '0';
        if (left === 0) cont.removeAttribute('disabled');
      };
      overlayTimer = setInterval(update, 250);
      update();
    } else {
      panel.append(
        h('h2', { class: 'dsb-title', text: "That's today's Reel." }),
        h('p', {
          class: 'dsb-body',
          text: `Reels are limited to ${settings.reelsPerDay} per day, and nothing plays after it.`,
        }),
        h('div', { class: 'dsb-actions' }, h('a', { class: 'dsb-btn dsb-primary', href: '/', text: 'Back to feed' }), msg)
      );
    }
    document.body.append(h('div', { id: 'dsb-overlay', class: 'dsb-overlay', role: 'dialog', 'aria-modal': 'true' }, panel));
  }

  function togglePill(on) {
    const pill = document.getElementById('dsb-pill');
    if (on && !pill) {
      document.body.append(
        h('div', { id: 'dsb-pill', class: 'dsb-pill' }, h('span', { text: 'One Reel at a time. Nothing queued after this.' }), h('a', { href: '/', text: 'Done' }))
      );
    } else if (!on && pill) {
      pill.remove();
    }
  }

  function syncOverlays() {
    // A pending pause owns the screen, but only on feed pages so DMs stay reachable.
    const pauseHere = settings.enabled && settings.frictionOn && pauseActive() && frictionPage();
    if (pauseHere) {
      if (overlayKind !== 'pause') mountOverlay('pause');
      return;
    }
    if (overlayKind === 'pause') unmountOverlay();

    const v = settings.enabled && settings.reelsOn ? viewerInfo() : null;
    const blocked = !!v && seenReels.size >= settings.reelsPerDay && !(v.code && seenReels.has(v.code));
    if (blocked && overlayKind !== 'reel') mountOverlay('reel');
    if (!blocked && overlayKind === 'reel') unmountOverlay();

    const lock = !!v && !blocked;
    root.classList.toggle('dsb-reel-lock', lock);
    togglePill(lock);
  }

  // Never let a Reel keep playing behind an overlay.
  document.addEventListener(
    'play',
    (e) => {
      if (overlayKind && e.target instanceof HTMLMediaElement) {
        try { e.target.pause(); } catch { /* ignore */ }
      }
    },
    true
  );

  /* ------------------------------------------------------------------ */
  /* Main loop                                                          */
  /* ------------------------------------------------------------------ */
  function cleanupAll() {
    $$('[data-dsb-hidden]').forEach((n) => n.removeAttribute('data-dsb-hidden'));
    removeCard();
    unmountOverlay();
    togglePill(false);
    root.classList.remove('dsb-reel-lock', 'dsb-capped');
    clearDwell();
  }

  function tick() {
    if (!alive()) return;
    rolloverIfNeeded();
    if (!settings.enabled) {
      cleanupAll();
      return;
    }
    processFeed();
    syncOverlays();
    watchReelDwell();
    root.classList.toggle('dsb-capped', postsExhausted());
  }

  let scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      tick();
    }, 150);
  }

  function injectStyle() {
    const scoped = (prefix, list) => list.map((s) => `${prefix} ${s}`).join(',\n');
    const style = document.createElement('style');
    style.id = 'dsb-dynamic-style';
    style.textContent =
      `${scoped('html.dsb-reel-lock main', SELECTORS.reelNav)} { display: none !important; }\n` +
      `${scoped('html.dsb-capped main', SELECTORS.loadingSpinner)} { display: none !important; }\n`;
    (document.head || root).append(style);
  }

  function onStorageChanged(changes, area) {
    if (!alive()) return;
    if (area === 'sync') {
      const next = { ...settings };
      for (const [k, c] of Object.entries(changes)) if (k in DEFAULTS) next[k] = c.newValue ?? DEFAULTS[k];
      settings = sanitize(next);
      schedule();
    } else if (area === 'local' && changes.dsbState) {
      const n = changes.dsbState.newValue;
      if (!n || n.day !== todayKey() || (n.epoch || 0) > (state.epoch || 0)) {
        hydrate(n); // reset elsewhere (new day, or "reset today" in the popup)
      } else {
        (n.posts || []).forEach((k) => seenPosts.add(k));
        (n.reels || []).forEach((k) => seenReels.add(k));
        state.pauses = Math.max(state.pauses, n.pauses || 0);
        state.pauseUntil = n.pauseUntil || 0;
      }
      schedule();
    }
  }

  async function init() {
    settings = sanitize(await store.get('sync', DEFAULTS));
    hydrate((await store.get('local', { dsbState: null })).dsbState);

    injectStyle();
    lastTop.set(scrollingEl(), scrollingEl().scrollTop);

    document.addEventListener('scroll', onScroll, true);
    window.addEventListener('wheel', onWheel, { capture: true, passive: false });
    window.addEventListener('touchmove', onTouchMove, { capture: true, passive: false });
    window.addEventListener('keydown', onKeyDown, true);
    document.addEventListener('click', onClick, true);

    new MutationObserver(schedule).observe(root, { childList: true, subtree: true });
    let lastHref = location.href;
    setInterval(() => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        schedule();
      }
    }, 400);
    try { api.storage.onChanged.addListener(onStorageChanged); } catch { /* ignore */ }

    tick();
  }

  // Test hook: only exists when a test harness defines globalThis.__DSB_TEST__ before loading.
  if (globalThis.__DSB_TEST__) {
    globalThis.__DSB_TEST__.api = {
      tick,
      addScroll,
      frictionFactor,
      endPause,
      snapshot: () => ({
        accum,
        state: { ...state },
        seenPosts: [...seenPosts],
        seenReels: [...seenReels],
        overlayKind,
        settings: { ...settings },
      }),
    };
  }

  init();
})();
