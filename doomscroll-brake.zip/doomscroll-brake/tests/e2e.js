/*
 * End-to-end test: loads the real unpacked extension into Chromium (via Playwright) and drives a fake
 * instagram.com that is served locally through request interception (no network, no real Instagram).
 *
 *   NODE_PATH=$(npm root -g) node tests/e2e.js
 *
 * Needs: playwright with a Chromium build installed.
 */
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { chromium } = require('playwright');

const EXT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let failed = 0;
function check(name, ok, detail = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok || !detail ? '' : `  -> ${detail}`}`);
  if (!ok) failed += 1;
}

// Unpacked-extension id = sha256(path) mapped to a-p.
const extId = crypto
  .createHash('sha256')
  .update(EXT)
  .digest('hex')
  .slice(0, 32)
  .split('')
  .map((c) => String.fromCharCode(97 + parseInt(c, 16)))
  .join('');

/* ---------------------------- fake instagram.com ---------------------------- */
const article = (code, kind = 'p') =>
  `<article style="height:700px;box-sizing:border-box;border:1px solid #ccc;padding:8px">
     <a href="/${kind}/${code}/">${code}</a>
     <button aria-label="Like"><svg aria-label="Like" width="20" height="20"><circle cx="10" cy="10" r="8"/></svg></button>
   </article>`;

function homeHtml() {
  const items = [];
  for (let i = 1; i <= 14; i++) {
    if (i === 4) items.push(article('R1', 'reel'));
    else if (i === 8) items.push(article('R2', 'reel'));
    else items.push(article(`P${i}`));
  }
  return `<!doctype html><html><body style="margin:0"><main>${items.join('')}</main></body></html>`;
}

function reelsHtml() {
  return `<!doctype html><html><body style="margin:0"><main>
    <div id="viewer" style="height:100vh;overflow-y:scroll;scroll-snap-type:y mandatory">
      <section style="height:100vh;scroll-snap-align:start;background:#223"><video id="v1" muted loop></video>Reel A</section>
      <section style="height:100vh;scroll-snap-align:start;background:#322">Reel B (should be unreachable)</section>
    </div>
    <button id="nextBtn" aria-label="Navigate to next Reel" style="position:fixed;right:10px;top:50%">v</button>
  </main></body></html>`;
}

const pageFor = (pathname) => {
  if (pathname === '/') return homeHtml();
  if (/^\/reels?\//.test(pathname)) return reelsHtml();
  return '<!doctype html><html><body><main><h1>Direct messages</h1></main></body></html>';
};

/* --------------------------------- helpers ---------------------------------- */
async function readState(popup) {
  return popup.evaluate(async () => (await chrome.storage.local.get({ dsbState: null })).dsbState);
}
async function configure(popup, settings) {
  await popup.evaluate(async (s) => {
    await chrome.storage.local.remove('dsbState');
    await chrome.storage.sync.clear();
    await chrome.storage.sync.set(s);
  }, settings);
}
const open = async (ctx, url) => {
  const p = await ctx.newPage();
  await p.setViewportSize({ width: 1100, height: 800 });
  await p.goto(url, { waitUntil: 'load' });
  await sleep(500);
  return p;
};

(async () => {
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsb-e2e-'));
  const ctx = await chromium.launchPersistentContext(userDataDir, {
    channel: 'chromium',
    headless: true,
    args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  });

  await ctx.route('https://www.instagram.com/**', (route) => {
    const u = new URL(route.request().url());
    if (route.request().resourceType() === 'document') {
      return route.fulfill({ status: 200, contentType: 'text/html', body: pageFor(u.pathname) });
    }
    return route.fulfill({ status: 204, body: '' });
  });

  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  check('extension loads and popup opens', (await popup.title()) === 'Doomscroll Brake');

  /* ------------------------------ 1. finite feed ------------------------------ */
  await configure(popup, { postsPerDay: 3, frictionOn: false, reelsOn: false });
  let page = await open(ctx, 'https://www.instagram.com/');
  for (let i = 0; i < 6 && !(await page.$('#dsb-card')); i++) {
    await page.mouse.move(500, 400);
    await page.mouse.wheel(0, 700);
    await sleep(450);
  }
  const hiddenCap = await page.$$eval('[data-dsb-hidden="cap"]', (n) => n.length);
  const total = await page.$$eval('main article', (n) => n.length);
  check('finite feed: "all caught up" card appears after the daily cap', !!(await page.$('#dsb-card')));
  check('finite feed: posts beyond the cap are hidden', hiddenCap === total - 3, `hidden=${hiddenCap} total=${total}`);
  const cardNext = await page.$eval('#dsb-card', (c) => c.nextElementSibling?.tagName);
  check('finite feed: card sits inline right before the hidden posts', cardNext === 'ARTICLE');
  await sleep(600);
  const st1 = await readState(popup);
  check('finite feed: exactly 3 posts counted and saved', st1 && st1.posts.length === 3, JSON.stringify(st1?.posts));

  // Reload: already-seen posts stay visible, new ones stay hidden immediately.
  await page.reload({ waitUntil: 'load' });
  await sleep(500);
  const afterReload = await page.$$eval('main article', (n) => n.map((a) => a.hasAttribute('data-dsb-hidden')));
  check('finite feed: cap survives a page reload', afterReload.filter(Boolean).length === afterReload.length - 3);
  await page.close();

  /* --------------------------- 2. one Reel in the feed --------------------------- */
  await configure(popup, { postsPerDay: 500, frictionOn: false, reelsOn: true, reelsPerDay: 1 });
  page = await open(ctx, 'https://www.instagram.com/');
  for (let i = 0; i < 4; i++) {
    await page.mouse.move(500, 400);
    await page.mouse.wheel(0, 700);
    await sleep(450);
  }
  const reelStates = await page.$$eval('main article', (n) =>
    n.map((a) => [a.querySelector('a').textContent, a.dataset.dsbHidden || ''])
  );
  const r1 = reelStates.find(([c]) => c === 'R1');
  const r2 = reelStates.find(([c]) => c === 'R2');
  check('feed Reels: the first Reel you see stays visible', r1 && r1[1] === '', JSON.stringify(r1));
  check('feed Reels: the next Reel is not suggested (hidden)', r2 && r2[1] === 'reel', JSON.stringify(r2));
  const normalHidden = reelStates.filter(([c, h]) => c.startsWith('P') && h).length;
  check('feed Reels: normal posts are untouched', normalHidden === 0);
  await page.close();

  /* ------------------------------ 3. Reels viewer ------------------------------ */
  await configure(popup, { frictionOn: false, reelsOn: true, reelsPerDay: 1 });
  page = await open(ctx, 'https://www.instagram.com/reels/R1/');
  check('viewer: locked to a single Reel', await page.$eval('html', (h) => h.classList.contains('dsb-reel-lock')));
  check('viewer: reminder pill is shown', !!(await page.$('#dsb-pill')));
  check('viewer: no blocking overlay on the first Reel', !(await page.$('#dsb-overlay')));
  check('viewer: "next Reel" arrow is hidden', await page.$eval('#nextBtn', (b) => getComputedStyle(b).display === 'none'));

  await page.mouse.move(500, 400);
  await page.mouse.wheel(0, 800);
  await sleep(500);
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('PageDown');
  await sleep(500);
  const viewerTop = await page.$eval('#viewer', (v) => v.scrollTop);
  check('viewer: mouse wheel and keys cannot reach the next Reel', viewerTop === 0, `scrollTop=${viewerTop}`);

  await sleep(2000);
  const st3 = await readState(popup);
  check('viewer: the Reel is counted after a short dwell', st3 && st3.reels.includes('R1'), JSON.stringify(st3?.reels));
  check('viewer: still allowed to keep watching that same Reel', !(await page.$('#dsb-overlay')));
  await page.close();

  page = await open(ctx, 'https://www.instagram.com/reels/');
  check('viewer: opening Reels after the allowance is used shows the block screen', !!(await page.$('#dsb-overlay')));
  const overlayText = await page.$eval('#dsb-overlay', (o) => o.textContent);
  check('viewer: block screen says today\'s Reel is done', /today's Reel/.test(overlayText));
  await page.close();

  page = await open(ctx, 'https://www.instagram.com/reels/R2/');
  check('viewer: a different Reel is blocked too', !!(await page.$('#dsb-overlay')));
  await page.close();

  page = await open(ctx, 'https://www.instagram.com/reels/R1/');
  check('viewer: re-opening the Reel you already watched is fine', !(await page.$('#dsb-overlay')));
  await page.close();

  /* ----------------------------- 4. scroll friction ----------------------------- */
  await configure(popup, { postsPerDay: 500, reelsOn: false, frictionOn: true, frictionStartScreens: 1, pauseAfterScreens: 3, pauseSeconds: 5 });
  page = await open(ctx, 'https://www.instagram.com/');
  await page.mouse.move(500, 400);

  const deltas = [];
  let paused = false;
  for (let i = 0; i < 80 && !paused; i++) {
    const before = await page.evaluate(() => window.scrollY);
    await page.mouse.wheel(0, 200);
    await sleep(130);
    const after = await page.evaluate(() => window.scrollY);
    deltas.push(after - before);
    paused = !!(await page.$('#dsb-overlay'));
  }
  const early = deltas[0];
  const late = deltas.slice(-6, -1).reduce((a, b) => a + b, 0) / Math.max(1, deltas.slice(-6, -1).length);
  check('friction: early scrolling is at full speed', early >= 150, `first delta=${early}`);
  check('friction: scrolling gets heavier the longer you go', late < early * 0.8, `early=${early} late~${Math.round(late)}`);
  check('friction: a forced pause overlay appears', paused);

  const overlay = await page.$('#dsb-overlay');
  if (overlay) {
    const contDisabled = await page.$eval('#dsb-overlay .dsb-primary', (b) => b.hasAttribute('disabled'));
    check('pause: "Keep scrolling" is locked during the countdown', contDisabled);
    const y0 = await page.evaluate(() => window.scrollY);
    await page.mouse.wheel(0, 600);
    await page.keyboard.press('PageDown');
    await sleep(400);
    const y1 = await page.evaluate(() => window.scrollY);
    check('pause: the page cannot be scrolled behind the overlay', y0 === y1, `${y0} -> ${y1}`);

    // A refresh must not bypass the pause.
    await page.reload({ waitUntil: 'load' });
    await sleep(500);
    check('pause: survives a page refresh', !!(await page.$('#dsb-overlay')));

    // The inbox stays reachable.
    const dm = await open(ctx, 'https://www.instagram.com/direct/inbox/');
    check('pause: messages page is not blocked', !(await dm.$('#dsb-overlay')));
    await dm.close();

    await sleep(5300);
    const enabled = await page.$eval('#dsb-overlay .dsb-primary', (b) => !b.hasAttribute('disabled'));
    check('pause: "Keep scrolling" unlocks when the countdown ends', enabled);
    await page.click('#dsb-overlay .dsb-primary');
    await sleep(300);
    check('pause: overlay closes after you choose to continue', !(await page.$('#dsb-overlay')));
    const y2 = await page.evaluate(() => window.scrollY);
    await page.mouse.wheel(0, 200);
    await sleep(300);
    const y3 = await page.evaluate(() => window.scrollY);
    check('pause: scrolling works again afterwards', y3 > y2, `${y2} -> ${y3}`);
  }
  await page.close();

  /* ------------------------------------ 5. popup ------------------------------------ */
  await configure(popup, {});
  await popup.reload();
  await popup.fill('#postsPerDay', '40');
  await popup.dispatchEvent('#postsPerDay', 'change');
  await sleep(300);
  const synced = await popup.evaluate(async () => (await chrome.storage.sync.get('postsPerDay')).postsPerDay);
  check('popup: changing a setting is saved', synced === 40, String(synced));
  await popup.fill('#postsPerDay', '1');
  await popup.dispatchEvent('#postsPerDay', 'change');
  await sleep(300);
  check('popup: out-of-range values are clamped', (await popup.inputValue('#postsPerDay')) === '3');
  await popup.screenshot({ path: path.join(os.tmpdir(), 'dsb-popup.png') });

  await ctx.close();
  console.log(failed ? `\n${failed} check(s) failed` : '\nAll checks passed');
  process.exit(failed ? 1 : 0);
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
