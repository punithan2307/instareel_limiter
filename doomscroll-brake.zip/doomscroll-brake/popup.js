(() => {
  'use strict';
  const { DEFAULTS, sanitize, todayKey, blankState } = globalThis.DSB;
  const api = globalThis.browser ?? globalThis.chrome;

  const BOOLS = ['enabled', 'feedCapOn', 'frictionOn', 'reelsOn'];
  const NUMS = ['postsPerDay', 'frictionStartScreens', 'pauseAfterScreens', 'pauseSeconds', 'reelsPerDay'];
  const $ = (id) => document.getElementById(id);

  let settings = sanitize(DEFAULTS);

  function renderSettings() {
    for (const k of BOOLS) $(k).checked = settings[k];
    for (const k of NUMS) $(k).value = settings[k];
  }

  function renderStats(state) {
    const s = state && state.day === todayKey() ? state : blankState();
    $('statPosts').textContent = `${s.posts.length} / ${settings.postsPerDay}`;
    $('statReels').textContent = `${s.reels.length} / ${settings.reelsPerDay}`;
    $('statPauses').textContent = String(s.pauses);
  }

  async function save() {
    for (const k of BOOLS) settings[k] = $(k).checked;
    for (const k of NUMS) settings[k] = $(k).value;
    settings = sanitize(settings);
    renderSettings(); // show the clamped values
    await api.storage.sync.set(settings);
    renderStats((await api.storage.local.get({ dsbState: null })).dsbState);
  }

  async function init() {
    settings = sanitize(await api.storage.sync.get(DEFAULTS));
    renderSettings();
    renderStats((await api.storage.local.get({ dsbState: null })).dsbState);

    for (const k of [...BOOLS, ...NUMS]) $(k).addEventListener('change', save);

    $('reset').addEventListener('click', async () => {
      await api.storage.local.set({ dsbState: { ...blankState(), epoch: Date.now() } });
      renderStats(null);
    });
  }

  init();
})();
