"""Generates icons/icon16.png, icon48.png and icon128.png (a brake-pause glyph on a dark rounded square)."""
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).parent / "icons"
OUT.mkdir(exist_ok=True)

SCALE = 4  # draw big, then downsample for smooth edges


def render(size: int) -> Image.Image:
    s = size * SCALE
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=(22, 24, 29, 255))

    # Two pause bars.
    bar_w, bar_h, gap = s * 0.14, s * 0.46, s * 0.12
    top = (s - bar_h) / 2
    left = (s - (2 * bar_w + gap)) / 2
    for i in range(2):
        x = left + i * (bar_w + gap)
        d.rounded_rectangle((x, top, x + bar_w, top + bar_h), radius=bar_w * 0.35, fill=(255, 255, 255, 255))

    # Small green dot, like an "on" indicator.
    r = s * 0.07
    cx, cy = s * 0.78, s * 0.22
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(34, 164, 93, 255))

    return img.resize((size, size), Image.LANCZOS)


for n in (16, 48, 128):
    render(n).save(OUT / f"icon{n}.png")
    print("wrote", OUT / f"icon{n}.png")
