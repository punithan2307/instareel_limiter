# Doomscroll Brake for Instagram

A browser extension that adds friction to instagram.com so endless scrolling stops being endless.

## What it does

| Feature | Behavior |
|---|---|
| **Finite feed** | After you've seen N distinct posts in a day (default 25), the rest of the home feed is hidden and replaced by an "You're all caught up" card. Posts you already saw stay visible. Resets at local midnight. |
| **Scroll friction** | On the home feed and Explore, scrolling gets progressively heavier after ~4 screens, and after ~10 screens a full-screen pause appears (15 s, then 30 s, 45 s, 60 s for later pauses that day). You have to click "Keep scrolling" yourself once the countdown ends. Liking, commenting, sharing or saving a post eases the counter by half. A pause survives page refreshes and applies across tabs. Messages stay reachable. |
| **One Reel at a time** | The Reels viewer is locked to the single Reel you opened: wheel, arrow keys, Page Up/Down, swipe and the next/previous arrows are all disabled, so no second Reel is ever queued. After your daily allowance (default 1 Reel), more Reels are hidden in the feed and the Reels viewer shows a block screen. Re-opening a Reel you already watched is fine. |

Click the toolbar icon to change any limit, see today's counts, or reset today.

## Install

**Chrome / Edge / Brave / Arc (desktop)**
1. Open `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode**.
3. Click **Load unpacked** and choose this folder.

**Firefox (desktop or Android)**
1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on** and choose `manifest.json`.
   (Temporary add-ons are removed when Firefox restarts. For a permanent install, the add-on must be signed via addons.mozilla.org.)

## Important limits

- **It only works in a browser, on instagram.com.** It cannot change the native Instagram app on iOS or Android. On a phone you can use it with Firefox for Android, or Kiwi Browser, while using instagram.com. On phones, the hard pause and the Reels lock apply; the gradual scroll slow-down needs a mouse wheel or keyboard, because touch scrolling can't be scaled.
- **Instagram changes its markup often.** Everything that depends on it is in the `SELECTORS` block at the top of `content.js`. If a feature stops working after an Instagram update, that's the place to adjust.
- **Hidden posts may still be prefetched.** Instagram loads posts in batches; the extension hides the extras but cannot stop the page from fetching them in the background.
- The "engagement eases the counter" rule matches English button labels (Like, Comment, Share, Save).
- Counts are stored locally in your browser (`chrome.storage`). Nothing is sent anywhere.

## Project layout

```
manifest.json   Manifest V3 (Chrome, Edge, Firefox 128+)
shared.js       Defaults, validation, per-day state shape (shared by content script and popup)
content.js      All the logic that runs on instagram.com
content.css     Styles for the card, overlays and hidden posts
popup.html/.css/.js   Settings and today's stats
icons/          Toolbar icons (regenerate with: python3 make_icons.py)
tests/e2e.js    End-to-end test (Playwright + Chromium) against a local fake Instagram
```

## Run the tests

The test loads the unpacked extension into Chromium and drives a fake instagram.com served by request interception (no network needed):

```
npm i -D playwright && npx playwright install chromium
node tests/e2e.js
```

## Changing the defaults

Defaults live in `shared.js` (`DEFAULTS`). Users can override them in the popup.
