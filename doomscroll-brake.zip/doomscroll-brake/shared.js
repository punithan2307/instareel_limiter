/*
 * Shared between the content script and the popup.
 * Settings defaults, validation, and the shape of the per-day state.
 */
(() => {
  'use strict';

  const DEFAULTS = {
    enabled: true,

    // Finite feed: after this many distinct posts are seen in a day, the rest of the home feed is hidden.
    feedCapOn: true,
    postsPerDay: 25,

    // Scroll friction: scrolling gets heavier after `frictionStartScreens` screens of scrolling,
    // then a forced pause kicks in at `pauseAfterScreens`. Pauses get longer each time they happen in a day.
    frictionOn: true,
    frictionStartScreens: 4,
    pauseAfterScreens: 10,
    pauseSeconds: 15,

    // One Reel at a time: the Reels viewer never advances to a next Reel,
    // and once the daily allowance is used, further Reels are hidden or blocked.
    reelsOn: true,
    reelsPerDay: 1,
  };

  const clamp = (value, fallback, min, max) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : fallback;
  };

  function sanitize(input) {
    const o = { ...DEFAULTS, ...(input || {}) };
    o.postsPerDay = clamp(o.postsPerDay, DEFAULTS.postsPerDay, 3, 500);
    o.frictionStartScreens = clamp(o.frictionStartScreens, DEFAULTS.frictionStartScreens, 1, 50);
    o.pauseAfterScreens = Math.max(
      o.frictionStartScreens + 1,
      clamp(o.pauseAfterScreens, DEFAULTS.pauseAfterScreens, 2, 100)
    );
    o.pauseSeconds = clamp(o.pauseSeconds, DEFAULTS.pauseSeconds, 5, 300);
    o.reelsPerDay = clamp(o.reelsPerDay, DEFAULTS.reelsPerDay, 1, 20);
    for (const k of ['enabled', 'feedCapOn', 'frictionOn', 'reelsOn']) o[k] = !!o[k];
    return o;
  }

  // Local calendar day, e.g. "2026-10-23". Budgets reset when this changes.
  function todayKey() {
    const d = new Date();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${mm}-${dd}`;
  }

  // Per-day state kept in chrome.storage.local under "dsbState".
  function blankState() {
    return {
      day: todayKey(),
      epoch: 0,        // bumped by the popup's "reset today" button
      posts: [],       // shortcodes of posts seen today
      reels: [],       // shortcodes of Reels seen today
      pauses: 0,       // forced pauses so far today
      scrollPx: 0,     // scrolled distance since the last break
      pauseUntil: 0,   // ms timestamp; non-zero while a pause is waiting to be dismissed
    };
  }

  globalThis.DSB = Object.freeze({ DEFAULTS, sanitize, todayKey, blankState });
})();
